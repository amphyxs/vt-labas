package lab8.client.presenter.exceptions;

/**
 * Ошибка пустой команды (например, пустая строка из пробелов была считана при вводе команды)
 */
public class NullCommandException extends Exception {
    
}
