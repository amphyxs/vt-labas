package lab8.client.presenter.commands;

import lab8.client.presenter.exceptions.*;


/**
 * Команда очистки коллекции
 */
public class ClearCommand extends AbstractNetworkCommand {
    
    @Override
    public String getName() {
        return "clear";
    }

    @Override
    public String getDescription() {
        return "очистить коллекцию";
    }

    @Override
    public String[] getArgsNames() {
        return null;
    }

    @Override
    public void setArg(String argName, String valueString) throws BadCommandArgException {
        return;
    }

    @Override
    public Object getArg(String argName) throws CommandArgNotFound {
        throw new CommandArgNotFound(getName(), argName);
    }

}
