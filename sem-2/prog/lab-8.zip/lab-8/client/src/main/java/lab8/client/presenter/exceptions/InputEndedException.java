package lab8.client.presenter.exceptions;

/**
 * Ошибка окончания ввода (например, дошли до EOF)
 */
public class InputEndedException extends Exception {
    
}
