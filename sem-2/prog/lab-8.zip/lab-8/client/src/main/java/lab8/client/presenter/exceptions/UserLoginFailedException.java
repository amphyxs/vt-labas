package lab8.client.presenter.exceptions;

public class UserLoginFailedException extends Exception {
    public UserLoginFailedException(String message) {
        super(message);
    }
}
