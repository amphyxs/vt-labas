/**
 * Команды представления
 */
package lab8.client.presenter.commands;
