/**
 * Формы (инструмент для обеспечения внесения значений пользователем)
 */
package lab7.serializedobjects.form;
