package lab7.serializedobjects.dataclasses;


/**
 * Холодное оружие
 */
public enum MeleeWeapon {
    CHAIN_SWORD,
    CHAIN_AXE,
    POWER_BLADE;
}
