
/**
 * Исключения модели
 */
package lab7.serializedobjects.exceptions;
