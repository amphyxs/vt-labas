package lab7.serializedobjects.dataclasses;


/**
 * Категория бойца космодесанта Адептус Астартес
 */
public enum AstartesCategory {
    SUPPRESSOR,
    TACTICAL,
    TERMINATOR,
    APOTHECARY;
}
