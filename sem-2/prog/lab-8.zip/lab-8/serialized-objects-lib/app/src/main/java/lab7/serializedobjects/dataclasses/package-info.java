/**
 * Классы объектов данных
 */
package lab7.serializedobjects.dataclasses;
