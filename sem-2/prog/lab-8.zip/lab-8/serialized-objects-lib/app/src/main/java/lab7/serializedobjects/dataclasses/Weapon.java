package lab7.serializedobjects.dataclasses;


/**
 * Огнестрельное оружие
 */
public enum Weapon {
    MELTAGUN,
    GRENADE_LAUNCHER,
    MISSILE_LAUNCHER;
}
