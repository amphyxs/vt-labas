package lab7.serializedobjects;


public enum MessagesType {
    INFO,
    ERROR,
    RESULT
}
