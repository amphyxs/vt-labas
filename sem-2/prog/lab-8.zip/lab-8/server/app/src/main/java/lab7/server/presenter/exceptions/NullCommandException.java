package lab7.server.presenter.exceptions;

/**
 * Ошибка пустой команды (например, пустая строка из пробелов была считана при вводе команды)
 */
public class NullCommandException extends Exception {
    
}
