/**
 * Модель данных
 */
package lab7.server.model;
