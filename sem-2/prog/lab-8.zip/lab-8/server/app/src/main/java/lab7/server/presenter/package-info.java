/**
 * Представление
 */
package lab7.server.presenter;
