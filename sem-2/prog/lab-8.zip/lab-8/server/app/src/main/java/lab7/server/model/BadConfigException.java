package lab7.server.model;


public class BadConfigException extends Exception {
    public BadConfigException(String message) {
        super(message);
    }
}
