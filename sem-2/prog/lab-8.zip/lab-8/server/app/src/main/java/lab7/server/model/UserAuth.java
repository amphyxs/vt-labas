package lab7.server.model;

public class UserAuth {    
}
